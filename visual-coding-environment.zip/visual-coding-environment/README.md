# Scratch starter project

To get started:

- Run `npm i` to install dependencies
- Run `npm start` and open http://localhost:3000 to see the app
#   M I T  
 