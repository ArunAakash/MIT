import React, { useState } from "react";
import Sidebar from "./components/Sidebar";
import MidArea from "./components/MidArea";
import PreviewArea from "./components/PreviewArea";

function App() {
  const [actions, setActions] = useState([]);
  const [play, setPlay] = useState([]);
  const [history, setHistory] = useState([]);

  const handleDrop = (e) => {
    const blockType = e.dataTransfer.getData("text");
  
    setActions([...actions, blockType]);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleClick = (item) => {
   console.log('item',item);
    setPlay([...actions]);
  };

  const handleSave = () => {
    setHistory((prev) => [...prev, { actions: actions }]);
    setActions([]);
  };

  const sendSelected = (val) => {
    setActions([...val?.actions]);
  };
  return (
    <div className="bg-blue-100 pt-6 font-sans">
      <div className="h-screen overflow-hidden flex flex-row">
        <div className="w-1/4 h-screen overflow-hidden flex flex-col bg-white border-r border-gray-200">
          <Sidebar />
        </div>

        <div
          className="w-1/2 h-screen overflow-hidden flex flex-col bg-white border-l border-r border-gray-200"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
        >
          <MidArea
            actions={actions}
            handleClick={handleClick}
            handleSave={handleSave}
          />
        </div>
        <div className="w-1/4 h-screen overflow-hidden flex flex-col bg-white border-l border-gray-200">
          <PreviewArea
            sendSelected={sendSelected}
            history={history}
            play={play}
          />
        </div>
      </div>
      {/* <button
        onClick={replayActions}
        className="m-4 p-2 bg-blue-500 text-white rounded"
      >
        Replay Actions
      </button> */}
    </div>
  );
}

export default App;
