import React from "react";

function MidArea({ actions, handleClick,handleSave }) {
  return (
    <div className="p-4 space-y-4 flex-1 h-full overflow-auto">
      <div className="text-lg font-bold">Drop Area</div>
      <div className="flex-1 border-2 border-dashed border-gray-300 p-4">
        {actions.map((item, index) => (
          <div
            onClick={() => handleClick(item)}
            key={index}
            className="p-2 bg-blue-200 rounded"
          >
            {item}
          </div>
        ))}
      </div>
      <div class="text-right">
        <button onClick={handleSave} class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          Save & 
        </button>
      </div>
    </div>
  );
}

export default MidArea;
