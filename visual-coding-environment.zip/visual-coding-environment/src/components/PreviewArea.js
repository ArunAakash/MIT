import React, { useRef, useEffect } from "react";
import CatSprite from "./CatSprite";

function PreviewArea({ history, sendSelected, play }) {
  const spriteRef = useRef(null);
console.log('play',play);
  const executeAction = (action) => {
    if (!spriteRef.current) return;

    switch (action) {
      case "Move 10 steps":
        spriteRef.current.style.transform += "translateX(10px)";
        break;
      case "Turn 15 degrees":
        spriteRef.current.style.transform += "rotate(15deg)";
        break;
      case "Turn -15 degrees":
        spriteRef.current.style.transform += "rotate(-15deg)";
        break;
      case "Say hello 2 seconds":
        spriteRef.current.style.transform += "";
        break;
      case "Increase Size":
        spriteRef.current.style.transform = "scale(1.5)";
        break;
      case "Decrease Size":
        spriteRef.current.style.transform = "scale(1)";
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    play.forEach((action, index) => {
      setTimeout(() => executeAction(action), index * 1000);
    });
  }, [play]);

  return (
    <div className="flex-none h-full overflow-y-auto p-2">
      <CatSprite ref={spriteRef} />
      {history &&
        history.length > 0 &&
        history.map((item, index) => {
          return (
            <div
              onClick={() => sendSelected(item)}
              key={index}
              style={{
                borderRadius: "7px",
                background: "dodgerBlue",
                margin: "10px",
              }}
            >
              {item.actions.map((item1, index) => {
                return (
                  <div
                    key={index}
                    style={{
                      color: "white",
                      textAlign: "center",
                      padding: "10px",
                    }}
                  >
                    {item1}
                  </div>
                );
              })}
            </div>
          );
        })}
    </div>
  );
}

export default PreviewArea;
