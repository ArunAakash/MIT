import React from 'react';

const LooksBlock = ({ onDrop }) => {
  const handleDragStart = (e) => {
    e.dataTransfer.setData('text/plain', 'looks');
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="block looks-block"
    >
      Looks Block
    </div>
  );
};

export default LooksBlock;
