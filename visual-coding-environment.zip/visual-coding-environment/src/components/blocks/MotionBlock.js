import React from 'react';

const MotionBlock = ({ onDrop }) => {
  const handleDragStart = (e) => {
    e.dataTransfer.setData('text/plain', 'motion');
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="block motion-block"
    >
      Motion Block
    </div>
  );
};

export default MotionBlock;
